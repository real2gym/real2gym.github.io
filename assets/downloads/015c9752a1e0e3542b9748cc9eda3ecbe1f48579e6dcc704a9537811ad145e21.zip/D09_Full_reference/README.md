# D09: Full-reference scene and recorded native trajectory

This is the candidate shown in the Full column of the D09 ablation figure.
Its original experimental condition is `wo_event_sampling`, candidate03.
The geometry is preserved from that candidate; the Blender scene contains
the recorded MuJoCo motion. This is not the separate old-Full-guided continuation.

## Contents

- `scene.xml` and `dependencies/`: portable native MuJoCo scene, validated in MuJoCo 3.3.7.
- `native_trajectory.npz`: all 11,909 recorded states from a native `mj_step` execution,
  including time, qpos, qvel, ctrl, body/camera poses, contacts counts, and diagnostic arrays.
- `scene.blend`: the same scene geometry with 286 animation frames at 12 fps,
  bound to the recorded native body motion. Cameras: 22008760, 24400334, 18026681.
- `source_control.npz` and `source_mapping.json`: all 337 source-control rows and their native-state correspondence.
- `results.json`, `physical_outcome.json`, and `verification.json`: actual outcome and checks.
- `replay.py`: view the saved states or validate loading without opening a window.

## Outcome and timing

The complete source timeline was executed: 337/337 source-control rows,
23.816 seconds of native simulation. The four-cup stacking task was NOT completed
(`task_success: false`, `failed stack spatial condition`). Full timeline coverage
must not be interpreted as task success. No corrective reset or successful
continuation is substituted in this delivery.

The videos show saved native states. MuJoCo videos are 24 fps and Blender videos
are 12 fps, both 23.833333 seconds including the final display interval.
Blender materials and the static glTF website previews can differ from native
MuJoCo shading. The browser scene viewer is a static geometry viewer.

## Usage

Install `numpy` and `mujoco==3.3.7` in your own Python environment, then run:

```sh
python replay.py --check
python replay.py
# macOS interactive viewer:
mjpython replay.py
```

Playback assigns the saved qpos/qvel and calls `mj_forward`; it is a recorded-state
visualization, not a new physical simulation or a new success evaluation.
`--check` loads the portable XML and verifies five recorded body-pose snapshots.

`provenance.json` and `checksums.sha256` identify the exact original candidate,
native output, and all bundled files. No old-Full-guided continuation is included.
