from pathlib import Path
import argparse
import time
import numpy as np
import mujoco

p = argparse.ArgumentParser()
p.add_argument('--check', action='store_true')
p.add_argument('--rate', type=float, default=1.0)
a = p.parse_args()
if a.rate <= 0:
    p.error('--rate must be positive')
r = Path(__file__).resolve().parent
m = mujoco.MjModel.from_xml_path(str(r / 'scene.xml'))
d = mujoco.MjData(m)
z = np.load(r / 'native_trajectory.npz', allow_pickle=False)
times = z['time_s']
assert z['qpos'].shape == (len(times), m.nq)
assert np.isfinite(z['qpos']).all() and np.all(np.diff(times) > 0)

def state(i):
    d.qpos[:] = z['qpos'][i]
    d.qvel[:] = z['qvel'][i]
    d.ctrl[:] = z['ctrl'][i]
    d.time = float(times[i])
    mujoco.mj_forward(m, d)

errors = []
for i in np.linspace(0, len(times)-1, 5, dtype=int):
    state(i)
    errors.append(float(np.abs(d.xpos-z['body_pos'][i]).max()))
assert max(errors) < 1e-8, errors
print({'states':len(times), 'duration_s':float(times[-1]),
       'max_body_position_error_m':max(errors), 'task_success':False})
if not a.check:
    import mujoco.viewer
    state(0)
    with mujoco.viewer.launch_passive(m, d) as viewer:
        start = time.monotonic()
        while viewer.is_running():
            elapsed = (time.monotonic()-start)*a.rate
            i = min(len(times)-1, int(np.searchsorted(times, elapsed)))
            state(i)
            viewer.sync()
            if elapsed > float(times[-1]):
                break
            time.sleep(1/120)
