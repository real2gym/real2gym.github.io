# D09 Full: corrected native success

This package contains the final frozen-input regression of the corrected Full scene.
It preserves the current Full object geometry, source arm joint references,
source timestamps, and initial state. The changes are control-interface and
contact calibration, solver timestep, and the wrist-camera mount. No historical
successful continuation is substituted for this run.

The frozen-input regression and the earlier media-source validated run have
exactly equal values in every saved state and contact array, and their trajectory
files have the same SHA256. The archive stores this identical trajectory once;
`provenance.json` records both source-run aliases and preserves both result files.

## Native outcome

The final run executed all **337/337** reference rows plus **3 seconds** of
settling: **53,630 native steps**, **26.815 seconds**, MuJoCo **3.3.7**.
The independent audit confirms sequential nesting and the released final
bottom-to-top stack **B, C, A, D**. The released stable window is **4.7645 s**.
Maximum measured penetration among contacts involving a cup is **1.55969 mm**;
this metric does not cover every robot/environment geometry pair. Solver warning
counts are zero. This is one deterministic simulated run, not a real-robot test.

## Contents

- `scene.xml`, `dependencies/`: portable native model and all 44 dependencies.
- `scene.blend`: the final Blender scene with the same recorded native motion.
- `initial_state.npz`, `control_reference.npz`: original initialization and all control rows.
- `sim_config.json`, `criteria.json`: runtime configuration and task criteria.
- `scripts/run_native.py`: byte-identical producer of the authoritative final run.
- The canonical trajectory identified by `provenance.json`: 1,610 full state samples at 60 Hz including
  exact t=0 and t=26.815 s, and per-step cup contact measurements for all 53,630 steps.
- `frozen_regression/result.json`, `validated_run/result.json`,
  `audit/final_native_audit.json`: recorded outcomes
  and independently recomputed final-run checks. The audit omits the separate
  historical discovery section and replaces machine paths with package paths.
- `native_inputs.json`, `native_run_receipt.json`, `native_evaluation.json`,
  `frozen_state_equivalence.json`: complete frozen inputs, actual native-run receipt,
  criteria evaluation and exact comparison to the media-source run. Package paths
  are normalized while all content hashes and the input signature are preserved.
- `geometry_and_correction_summary.json`: unchanged geometry and declared changes.
- `native_video_mapping.json`: 644 frames at 24 fps for each named native camera.
- `blender_time_mapping.json` and available Blender binding/verification records:
  the mapping from Blender frames to this trajectory.
- `provenance.json`, `checksums.sha256`: exact file identities.

When `media_hash_manifest.json` is present, the delivery also includes final
video identities and actual Blender visual-review records. Their referenced
images and videos are delivered separately, not included in this archive.
`blender_binding.json` distinguishes a zero position error against expected
float32 matrices from the stricter comparison to native float64 transforms:
the latter maximum position error is about **7.49e-8 m** across all 322 frames.

The optional videos are delivered separately and are not stored in this archive.
Native videos have 644 frames / 24 fps and Blender videos have 322 frames / 12 fps;
both display 26.833333 seconds. Native video frames use nearest saved states,
except that the final frame explicitly uses the exact terminal state at 26.815 s
(23.333 ms after its nominal 24 fps timestamp). The terminal state is displayed
for one video frame. Blender uses the same endpoint rule at its 12 fps rate.
The robot-mounted wrist camera can partly crop the final stack; its validated mounting
has not been changed to improve framing. Renderer shading can differ.

## Read back saved states

Install `numpy` and `mujoco==3.3.7`, then run from this directory:

```sh
python replay.py --check
python replay.py
# macOS interactive viewer:
mjpython replay.py
```

`--check` verifies every checksum, loads the XML, and compares nine FK snapshots
with saved body positions and orientations. Interactive playback assigns the
saved qpos/qvel/ctrl/time and calls `mj_forward`; **it does not run new dynamics**
and is not a new task-success evaluation. Blender animation and the videos are
also visualization of this same native execution.

## Execute a new native simulation

```sh
python scripts/run_native.py . 336 reproduced_native
```

This command creates `reproduced_native/trajectory.npz` and `result.json` using
`mj_step`, actuator controls, gravity and contacts. It consumes all source rows
and applies the same 3-second settling period. It also writes `progress.json`.
Use a distinct output name to preserve the bundled authoritative run. A new run
is a new result and should be evaluated independently; platform/runtime changes
may change floating-point behavior. No simulation was rerun by the video renderer,
archive builder, or independent readback validation.
