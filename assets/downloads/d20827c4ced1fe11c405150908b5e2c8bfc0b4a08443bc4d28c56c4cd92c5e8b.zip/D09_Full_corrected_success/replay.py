"""Saved-state viewer and portable model/FK validation; never calls mj_step."""
from pathlib import Path
import argparse
import hashlib
import json
import time
import numpy as np
import mujoco

p = argparse.ArgumentParser()
p.add_argument('--check', action='store_true', help='validate checksums, XML, and nine FK snapshots')
p.add_argument('--rate', type=float, default=1.0)
a = p.parse_args()
if a.rate <= 0:
    p.error('--rate must be positive')
r = Path(__file__).resolve().parent
checked = 0
for line in (r/'checksums.sha256').read_text().splitlines():
    expected, name = line.split('  ', 1)
    f = r/name
    assert f.is_relative_to(r) and f.is_file(), name
    assert hashlib.sha256(f.read_bytes()).hexdigest() == expected, name
    checked += 1
m = mujoco.MjModel.from_xml_path(str(r/'scene.xml'))
d = mujoco.MjData(m)
provenance = json.loads((r/'provenance.json').read_text())
z = np.load(r/provenance['canonical_trajectory'], allow_pickle=False)
t = z['time_s']
assert t[0] == 0 and np.all(np.diff(t) > 0)
assert z['qpos'].shape == (len(t),m.nq) and z['qvel'].shape == (len(t),m.nv)
assert all(np.isfinite(z[k]).all() for k in ['qpos','qvel','ctrl','body_xpos','body_xquat'])
def state(i):
    d.qpos[:] = z['qpos'][i]
    d.qvel[:] = z['qvel'][i]
    d.ctrl[:] = z['ctrl'][i]
    d.time = float(t[i])
    mujoco.mj_forward(m,d)
errors, quaternion_errors = [], []
snapshots = np.linspace(0,len(t)-1,9,dtype=int)
for i in snapshots:
    state(i)
    errors.append(float(np.abs(d.xpos-z['body_xpos'][i]).max()))
    quaternion_errors.append(float(np.abs(d.xquat-z['body_xquat'][i]).max()))
assert max(errors) < 1e-9, errors
assert max(quaternion_errors) < 1e-9, quaternion_errors
res = json.loads((r/'frozen_regression/result.json').read_text())
audit = json.loads((r/'audit/final_native_audit.json').read_text())
assert res['task_success'] is True and audit['independent_task_success'] is True
assert abs(float(t[-1])-res['duration']) < 1e-12
assert len(z['step_metrics']) == res['steps'] == 53630
assert len(z['source_time']) == res['source_rows_consumed'] == 337
assert m.body(m.cam_bodyid[m.camera('18026681').id]).name == 'fr3_link7'
inputs = json.loads((r/'native_inputs.json').read_text())
for key, ref in inputs['inputs'].items():
    for entry in ref if key == 'assets' else [ref]:
        assert hashlib.sha256((r/entry['path']).read_bytes()).hexdigest() == entry['sha256'], entry['path']
canonical = {k:sorted(x['sha256'] for x in v) if k == 'assets' else v['sha256']
             for k,v in inputs['inputs'].items()}
signature = hashlib.sha256(json.dumps(canonical,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
assert signature == inputs['inputs_sha256']
receipt = json.loads((r/'native_run_receipt.json').read_text())
evaluation = json.loads((r/'native_evaluation.json').read_text())
assert receipt['inputs_sha256'] == evaluation['inputs_sha256'] == signature
assert receipt['trajectory_sha256'] == evaluation['trajectory_sha256'] == hashlib.sha256((r/provenance['canonical_trajectory']).read_bytes()).hexdigest()
assert receipt['mode'] == 'native' and receipt['completed'] is True
assert evaluation['status'] == 'pass'
print(json.dumps({'mode':'saved_state_readback_no_new_simulation','mujoco_version':mujoco.__version__,
                  'checked_file_count':checked,'states':len(t),'native_steps':res['steps'],
                  'duration_s':float(t[-1]),'source_rows':len(z['source_time']),
                  'fk_snapshots':len(snapshots),'max_body_position_error_m':max(errors),
                  'max_body_quaternion_error':max(quaternion_errors),
                  'input_binding_verified':True,
                  'recorded_native_task_success':res['task_success']}))
if not a.check:
    import mujoco.viewer
    state(0)
    with mujoco.viewer.launch_passive(m,d) as viewer:
        viewer.opt.geomgroup[3] = 0
        start = time.monotonic()
        while viewer.is_running():
            elapsed = (time.monotonic()-start)*a.rate
            i = min(len(t)-1,int(np.searchsorted(t,elapsed)))
            if i > 0 and abs(t[i-1]-elapsed) < abs(t[i]-elapsed):
                i -= 1
            state(i)
            viewer.sync()
            if elapsed > t[-1]:
                break
            time.sleep(1/120)
